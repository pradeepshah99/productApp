import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ourbenefit-comp',
  templateUrl: './ourbenefit-comp.component.html',
  styleUrls: ['./ourbenefit-comp.component.css']
})
export class OurbenefitCompComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
