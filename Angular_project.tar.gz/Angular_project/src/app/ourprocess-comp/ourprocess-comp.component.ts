import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ourprocess-comp',
  templateUrl: './ourprocess-comp.component.html',
  styleUrls: ['./ourprocess-comp.component.css']
})
export class OurprocessCompComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
