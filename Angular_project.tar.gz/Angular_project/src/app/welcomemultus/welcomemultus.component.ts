import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-welcomemultus',
  templateUrl: './welcomemultus.component.html',
  styleUrls: ['./welcomemultus.component.css']
})
export class WelcomemultusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
