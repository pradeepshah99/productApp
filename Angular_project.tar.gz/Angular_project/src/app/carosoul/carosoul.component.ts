import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-carosoul',
  templateUrl: './carosoul.component.html',
  styleUrls: ['./carosoul.component.css']
})
export class CarosoulComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
